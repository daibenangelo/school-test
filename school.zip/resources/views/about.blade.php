<html lang="en">

<head>
    @include('layouts/head')
    <title>About</title>
</head>
<body>
    @include('layouts/navbar')
    <h1>About page</h1>
    <a href="/">Go to Home</a>
</body>

</html>