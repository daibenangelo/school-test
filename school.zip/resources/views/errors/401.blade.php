<html lang="en">

<head>
    @include("../layouts/head")
    <title>Error</title>
</head>
<body>
    <h1>401 Error</h1>
    <p>Whoops! An error has occured.</p>
    <a href="/">Go back to home page.</a>
</body>
</html>