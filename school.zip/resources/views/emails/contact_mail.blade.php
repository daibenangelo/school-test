<h1>Contact email from {{$name}}</h1>
<p>{{$body}}</p>