<html lang="en">
 
<head>
    @include("layouts/head");
     <title>Show Student</title>
</head>
<body>
    <h1>Show Student
 {{$id}}</h1>
    <p>Viewing student data of {{$name}}</h1>
    </body>

</html>