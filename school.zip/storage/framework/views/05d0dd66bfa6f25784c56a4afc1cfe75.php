<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="/js/welcome.js"></script>
    <link rel="stylesheet" href="/css/styles.css"/>
    <title>Home</title>
</head>
<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Home page</h1>
    <img src="/img/city.jpg" class="img-fluid" alt="manila at night"/>
    <button class="btn btn-primary" onclick="welcome()">Welcome</button>
    <a href="/about">Go to About</a>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/home.blade.php ENDPATH**/ ?>