<html lang="en">
 
<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
     <title>Create Subject</title>
</head>
<body>
    <h1>Create Subject</h1>
    <form action="/subjects" method="POST">
        <?php echo csrf_field(); ?>
        <label>Name: </label>
        <input type="text" name="subj_name" placeholder="ex. Intro to Programming"/><br>
        <label>Department: </label>
        <select name="department">
            <option value="Computer">Computer</option>
            <option value="Mathematics">Mathematics</option>
            <option value="Science">Science</option>
            <option value="Social Science">Social Science</option>
            <option value="History">History</option>
            <option value="MAPEH">MAPEH</option>
            <option value="Filipino">Filipino</option>
            <option value="English">English</option>
        </select>
        <input type="submit"/>
    </form>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/subjects_create.blade.php ENDPATH**/ ?>