<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p class="notif" style="background-color: red; color:white"><?php echo e($error); ?></p>  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if(Session::has('success')): ?>
    <p id="notif" style="background-color: green; color:white"><?php echo e(Session::get('success')); ?></p>
<?php elseif(Session::has('fail')): ?>
    <p id="notif" style="background-color: red; color:white"><?php echo e(Session::get('fail')); ?></p>
<?php endif; ?><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/layouts/errors.blade.php ENDPATH**/ ?>