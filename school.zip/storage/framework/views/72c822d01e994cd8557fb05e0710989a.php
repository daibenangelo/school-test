<html lang="en">

<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>My Orders</title>
</head>

<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>My Orders</h1>
    <?php if(count($orders) > 0): ?>
    <table class="table">
        <tr>
            <th>Order ID</th>
            <th>Time placed</th>
            <th>Status</th>
            <th>Total Price</th>
            <th>More Info</th>
        </tr>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($o->order_id); ?></td>
            <td><?php echo e($o->time_placed); ?></td>
            <td><?php echo e($o->status); ?></td>
            <td>PHP <?php echo e($o->total_price); ?></td>
            <td><a class="btn btn-warning" href="/order/<?php echo e($o->order_id); ?>">More info</a>
                <?php if($o->status == 'delivered'): ?>
                <img src="/img/spoon.jpg" alt="spoon and fork" style="width:30px">
                <span><a href="/order/<?php echo e($o->order_id); ?>">Confirm delivery</a></span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php else: ?>
    <p>No ongoing orders. <a href="/cafeteria">Check out the cafeteria!</a></p>
    <?php endif; ?>
    <a href="/order/completed">Show completed orders</a>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/my_orders.blade.php ENDPATH**/ ?>