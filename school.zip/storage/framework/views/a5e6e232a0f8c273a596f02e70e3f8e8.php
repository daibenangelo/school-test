<html lang="en">
     
<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Subject Show</title>
</head>

<body>
    <h1>Subjects Show</h1>
    <ul>
        <li>Subject ID: <?php echo e($subject->subject_id); ?></li>
        <li>Name: <?php echo e($subject->name); ?></li>
        <li>Department: <?php echo e($subject->department); ?></li>
    </ul>
    <h2>Classes</h2>
    <table class="table">
        <tr>
            <th>Class ID</th>
            <th>Room</th>
            <th>Schedule</th>
        </tr>
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($c -> class_id); ?></td>
            <td><?php echo e($c -> room); ?></td>
            <td><?php echo e($c -> schedule); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/subjects_show.blade.php ENDPATH**/ ?>