<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Products</title>
</head>

<body>
    <?php echo $__env->make("layouts/navbar-admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("layouts/errors", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Products</h1>
    <a class="btn btn-success" href="/admin/products/create">Add new product</a>
    <table class="table">
        <tr>
            <th>Product ID</th>
            <th>Image</th>
            <th>Name</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Restock</th>
        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($p->product_id); ?></td>
            <td><img src="/img/food/<?php echo e($p->image); ?>" style="width: 40px" /></td>
            <td><?php echo e($p->name); ?></td>
            <td>PHP <?php echo e($p->price); ?></td>
            <td><?php echo e($p->stock); ?></td>
            <td>
                <form action="/admin/products/restock/<?php echo e($p->product_id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="number" name="stock_change" value="0" style="width: 50px" />
                    <input type="submit" class="btn btn-warning" value="Restock" />
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/products.blade.php ENDPATH**/ ?>