<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Admin Register</title>
</head>

<body>
    <?php echo $__env->make("layouts/navbar-admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("layouts/errors", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Admin Register</h1>
    <form action="/admin/register/newadmin" method="POST">
        <?php echo csrf_field(); ?>
        <label>First name: </label>
        <input type="text" name="first_name"></input><br>
        <label>Last name: </label>
        <input type="text" name="last_name"></input><br>
        <label>Email address: </label>
        <input type="email" name="email"></input><br>
        <input type="submit">
    </form>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/register_admin.blade.php ENDPATH**/ ?>