<html lang="en">

<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Show User</title>
</head>

<body>
    <?php echo $__env->make('layouts/navbar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts/errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>User Info</h1>
    <img src="/img/user_profiles/<?php echo e($user -> image); ?>" style="width: 250px" />
    <ul>
        <li>User ID: <?php echo e($user -> user_id); ?></li>
        <li>First name: <?php echo e($user -> first_name); ?></li>
        <li>Last name: <?php echo e($user -> last_name); ?></li>
        <li>Email address: <?php echo e($user -> email); ?></li>
    </ul>
    <h1>Order History</h1>
    <table class="table">
        <tr>
            <th>Status</th>
            <th>Order ID</th>
            <th>Time Placed</th>
        </tr>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($o -> status); ?></td>
            <td><?php echo e($o -> order_id); ?></td>
            <td><?php echo e($o -> time_placed); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/admin_show_user.blade.php ENDPATH**/ ?>