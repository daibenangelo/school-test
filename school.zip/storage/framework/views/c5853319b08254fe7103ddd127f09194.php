<html lang="en">
 
<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
     <title>Create Student</title>
</head>
<body>
    <h1>Create Student</h1>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/students_create.blade.php ENDPATH**/ ?>