<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Admin Dashboard</title>
</head>

<body>
    <?php echo $__env->make("layouts/navbar-admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("layouts/errors", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Admin Dashboard</h1>
    <a href="/logout">Logout</a>
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <?php echo $chart->renderHtml(); ?>

            </div>

            <div class="col-lg-5">
                <?php echo $chart1->renderHtml(); ?>

            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <?php echo $chart2->renderHtml(); ?>

            </div>
        </div>
    </div>
</body>
<?php echo $__env->yieldContent('javascript'); ?>
<?php echo $chart->renderChartJsLibrary(); ?>

<?php echo $chart->renderJs(); ?>

<?php echo $chart1->renderChartJsLibrary(); ?>

<?php echo $chart1->renderJs(); ?>

<?php echo $chart2->renderChartJsLibrary(); ?>

<?php echo $chart2->renderJs(); ?>


</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/admin/admin_dashboard.blade.php ENDPATH**/ ?>