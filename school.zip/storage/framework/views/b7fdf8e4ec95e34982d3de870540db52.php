<html lang="en">

<head>
    <?php echo $__env->make("../layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Error</title>
</head>
<body>
    <h1>401 Error</h1>
    <p>Whoops! An error has occured.</p>
    <a href="/">Go back to home page.</a>
</body>
</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/errors/401.blade.php ENDPATH**/ ?>