<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>New Product</title>
</head>

<body>
    <?php echo $__env->make("layouts/navbar-admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("layouts/errors", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>New Product</h1>
    <form action="/admin/products" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label>Name: </label>
        <input type="text" name="name"></input><br>
        <label>Price: </label>
        <input type="number" name="price"></input><br>
        <label>Stock: </label>
        <input type="number" name="stock"></input><br>
        <label>Upload photo: </label>
        <input type="file" name="image"></input><br>
        <input type="submit" class="btn btn-success">
    </form>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/products_create.blade.php ENDPATH**/ ?>