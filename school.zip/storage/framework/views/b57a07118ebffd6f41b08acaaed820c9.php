<html lang="en">

<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Show Order</title>
    <style>
        .red {
            background-color: red !important;
            color: white;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <?php echo $__env->make('layouts/navbar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts/errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h1>Show Order</h1>
        <p>Order ID: <?php echo e($order_info->order_id); ?> (<?php echo e($order_info->time_placed); ?>)</p>
        <h2>Items Ordered</h2>
        <div class="row">
            <div class="col-lg-6">
                <table class="table">
                    <tr>
                        <th>Item</th>
                        <th>Info</th>
                    </tr>
                    <?php $__currentLoopData = $ordered_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td rowspan="4"><img src="/img/<?php echo e($op->image); ?>" width="100px" /></td>
                        <td><b>Name: <?php echo e($op->name); ?></b></td>
                    </tr>
                    <tr>
                        <td>Price: PHP <?php echo e($op->price); ?></td>
                    </tr>
                    <tr>
                        <td class="<?php echo e(($op->quantity >= $op->stock) ? 'red' : ''); ?>">Quantity: <?php echo e($op->quantity); ?> (in stock: <?php echo e($op->stock); ?>)</td>
                    </tr>
                    <tr>
                        <td>Total price: PHP <?php echo e($op->price * $op->quantity); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
            </div>
        </div>
        <h5>Total: PHP <?php echo e($total); ?></h5>
        <h2>Update Status</h2>
        <p>Status: <?php echo e($order_info->status); ?></p>
        <?php if($order_info->status == 'waiting'): ?>
        <form action="/admin/accept_order/<?php echo e($order_info->order_id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="submit" class="btn btn-success" value="Accept order">
        </form>
        <?php endif; ?>
        <?php if($order_info->status != 'cancelled' and $order_info->status != 'received'): ?>
        <?php if($order_info->status != 'waiting'): ?>
        <form action="/admin/update_order/<?php echo e($order_info->order_id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <select name="new_status">
                <option value="preparing">Preparing</option>
                <option value="waiting for delivery">Waiting for Delivery</option>
                <option value="delivering">Delivering</option>
                <option value="delivered">Delivered</option>
            </select>
            <input type="submit" class="btn btn-primary" value="Update status" />
        </form>
        <?php endif; ?>
        <form action="/admin/cancel_order/<?php echo e($order_info->order_id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="submit" class="btn btn-danger" value="Cancel order">
        </form>
        <?php endif; ?>
    </div>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/admin_show_order.blade.php ENDPATH**/ ?>