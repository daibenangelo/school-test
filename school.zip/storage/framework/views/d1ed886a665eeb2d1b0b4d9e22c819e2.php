<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>My Finished Orders</title>
</head>

<body>
    <?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("layouts/errors", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>My Finished Orders</h1>
    <table class="table">
        <tr>
            <th>Order ID</th>
            <th>Time Placed</th>
            <th>Status</th>
            <th>Total Price</th>
            <th>More Info</th>
        </tr>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($o->order_id); ?></td>
            <td><?php echo e($o->time_placed); ?></td>
            <td><?php echo e($o->status); ?></td>
            <td>PHP <?php echo e($o->total_price); ?></td>
            <td><a href="/order/<?php echo e($o->order_id); ?>" class="btn btn-warning">More Info</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/orders_completed.blade.php ENDPATH**/ ?>