<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Subjects</title>
</head>

<body>
    <?php echo $__env->make("layouts/navbar-admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("layouts/errors", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Subjects</h1>
    <a class="btn btn-success" href="/subjects/create">Add new subject</a>
    <?php if(count($subjects) > 0): ?>
    <table class="table">
        <tr>
            <th>Subject ID</th>
            <th>Name</th>
            <th>Department</th>
            <th>View subject</th>
            <th>Actions</th>
        </tr>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($s -> subject_id); ?></td>
            <td><?php echo e($s -> name); ?></td>
            <td><?php echo e($s -> department); ?></td>
            <td><a href="/subjects/<?php echo e($s -> subject_id); ?>">More info</a></td>
            <td><a class="btn btn-warning" href="/subjects/<?php echo e($s -> subject_id); ?>/edit">Edit</a>
                <a class="btn btn-danger" data-bs-toggle='modal' data-bs-target='#delete_<?php echo e($s -> subject_id); ?>'>Delete</a>
            </td>
            <?php echo $__env->make("layouts/modal_delete", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($subjects -> links('pagination::bootstrap-5')); ?>

    <?php else: ?>
    <p>No subjects found!</p>
    <?php endif; ?>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/subjects.blade.php ENDPATH**/ ?>