<html lang="en">
   
<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Edit subject</title>
</head>
<body>
    <h1>Edit Subject <?php echo e($subject -> subject_id); ?></h1>
    <form action="/subjects/<?php echo e($subject -> subject_id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label>Name: </label>
        <input type="text" name="subj_name" placeholder="ex. Intro to Programming" value="<?php echo e($subject -> name); ?>"/><br>
        <label>Department: </label>
        <select name="department">
            <option value="Computer" <?php echo e($subject -> department == 'Computer' ? 'selected' : ''); ?>>Computer</option>
            <option value="Mathematics" <?php echo e($subject -> department == 'Mathematics' ? 'selected' : ''); ?>>Mathematics</option>
            <option value="Science" <?php echo e($subject -> department == 'Science' ? 'selected' : ''); ?>>Science</option>
            <option value="Social Science" <?php echo e($subject -> department == 'Social Science' ? 'selected' : ''); ?>>Social Science</option>
            <option value="History" <?php echo e($subject -> department == 'History' ? 'selected' : ''); ?>>History</option>
            <option value="MAPEH" <?php echo e($subject -> department == 'MAPEH' ? 'selected' : ''); ?>>MAPEH</option>
            <option value="Filipino" <?php echo e($subject -> department == 'Filipino' ? 'selected' : ''); ?>>Filipino</option>
            <option value="English" <?php echo e($subject -> department == 'English' ? 'selected' : ''); ?>>English</option>
        </select>
        <input type="submit"/>
    </form>
</body>     
</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/subjects_edit.blade.php ENDPATH**/ ?>