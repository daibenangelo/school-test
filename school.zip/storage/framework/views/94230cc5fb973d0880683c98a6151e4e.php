<html lang="en">

<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Check Order</title>
</head>

<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Check Order</h1>
    <form action="/cafeteria/checkout" method="POST">
        <?php echo csrf_field(); ?>
        <ul>
            <?php for($i = 0; $i < count($p); $i++): ?> <?php if($sp[$i]> 0): ?>
                <img src="img/food/<?php echo e($p[$i]->image); ?>" width="50px">
                <li><?php echo e($p[$i]->name); ?>: <?php echo e($sp[$i]); ?> (PHP<?php echo e($p[$i]->price * $sp[$i]); ?>)</li>
                <?php endif; ?>
                <input type="text" name="order_<?php echo e($p[$i]->product_id); ?>" value="<?php echo e($sp[$i]); ?>" hidden />
                <?php endfor; ?>
        </ul>
        <h5>Total order is PHP<?php echo e($total); ?></h5>
        <input type="submit" class="btn btn-success" value="Place Order">
    </form>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/cafeteria_receipt.blade.php ENDPATH**/ ?>