<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Profile</title>
</head>

<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("layouts/errors", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Profile</h1>
    <p>Welcome, <?php echo e($s -> first_name); ?> <?php echo e($s -> last_name); ?></p>
    <img src="/img/user_profiles/<?php echo e($u -> image); ?>" width="250px" /><br>
    <form action="/profile/<?php echo e($u -> user_id); ?>/upload_photo" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="file" name="image"></input><br>
        <input type="submit" class="btn btn-success" value="Upload photo" />
    </form>
    <a href="/logout">Logout</a>
    <h2>Basic Info</h2>
    <ul>
        <li>Birthdate: <?php echo e($s -> birthdate); ?></li>
        <li>Gender: <?php echo e($s -> gender); ?></li>
        <li>Province: <?php echo e($s -> province); ?></li>
    </ul>
</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/profile.blade.php ENDPATH**/ ?>