<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Contact Us</title>
</head>

<body>
    <?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("layouts/errors", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <p>We would like to hear from you!</p>
    <form action="/contact" method="POST">
        <?php echo csrf_field(); ?>
        <label>Email address: </label>
        <input type="email" name="email"></input><br>
        <label>Name: </label>
        <input type="text" name="name"></input><br>
        <label>Content: </label><br>
        <textarea name="text"></textarea><br>
        <input type="submit" class="btn btn-primary">
    </form>

</body>

</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/contact.blade.php ENDPATH**/ ?>