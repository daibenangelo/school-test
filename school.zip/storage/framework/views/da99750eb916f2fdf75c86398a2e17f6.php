<html lang="en">

<head>
    <?php echo $__env->make("layouts/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Login</title>
</head>
<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("layouts/errors", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Login</h1>
    <form action="/login" method="POST">
        <?php echo csrf_field(); ?>
        <label>Email address: </label>
        <input type="email" name="email"></input><br>
        <label>Password: </label>
        <input type="password" name="password"></input><br>
        <input type="submit" value="Login">
    </form>
</body>
</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/login.blade.php ENDPATH**/ ?>