<html lang="en">

<head>
    <?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Order Success</title>
</head>

<body>
    <?php echo $__env->make('layouts/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Order Success!</h1>
    <p>Order ID: <?php echo e($order->order_id); ?></p>
    <a href="/order">Go to my orders</a>
</body>
</html><?php /**PATH C:\Users\AstiAd\Desktop\bootcamp\laravel\school\resources\views/cafeteria_success.blade.php ENDPATH**/ ?>