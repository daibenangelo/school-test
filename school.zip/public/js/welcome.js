function welcome() {
    alert("Welcome!");
}
